from telebot import TeleBot

mafia_bot = TeleBot('6085495552:AAGuy5i-D-15oRvKSVerpOE6DsOBfmfXRUU')

# вставка 1
@mafia_bot.message_handler(commands=['start'])
def start(message):
    mafia_bot.send_message(message.from_user.id, f'Привет, за кого будем играть?')
    mafia_bot.register_next_step_handler(message, choose_master_or_player)

@mafia_bot.message_handler(content_types=['text'])
def help_message(message):
    mafia_bot.send_message(message.from_user.id, 'чтобы понять, как пользоваться ботом напиши `/start`')

# вставка 2
def choose_master_or_player(message):
    user_id = message.from_user.id
    match message.text:
        case 'ведущий':
            mafia_bot.send_message(user_id, f'Приветствую тебя ведущий!')
        case 'игрок':
            mafia_bot.send_message(user_id, f'Приветствую тебя игрок!')
        case _:
            mafia_bot.send_message(user_id, 'вы ввели что-то не то')


mafia_bot.polling(none_stop=True, interval=0)
