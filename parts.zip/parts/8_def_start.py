from telebot import TeleBot

mafia_bot = TeleBot('6085495552:AAGuy5i-D-15oRvKSVerpOE6DsOBfmfXRUU')


# вставка 1
@mafia_bot.message_handler(commands=['start'])
def start(message):
    mafia_bot.send_message(message.from_user.id, f'Привет, пользователь!')


# вставка 2
@mafia_bot.message_handler(content_types=['text'])
def help_message(message):
    mafia_bot.send_message(message.from_user.id, 'чтобы понять, как пользоваться ботом напиши `/start`')


mafia_bot.polling(none_stop=True, interval=0)
