from telebot import TeleBot

mafia_bot = TeleBot('6085495552:AAGuy5i-D-15oRvKSVerpOE6DsOBfmfXRUU')


@mafia_bot.message_handler(content_types=['text'])
def start(message):
    mafia_bot.send_message(message.from_user.id, f'Привет, {message.text}!')


mafia_bot.polling(none_stop=True, interval=0)
