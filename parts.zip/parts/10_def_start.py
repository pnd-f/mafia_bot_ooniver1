from telebot import TeleBot, types

mafia_bot = TeleBot('6085495552:AAGuy5i-D-15oRvKSVerpOE6DsOBfmfXRUU')

# изменение 1
@mafia_bot.message_handler(commands=['start'])
def start(message):
    user_id = message.from_user.id
    keyboard = types.InlineKeyboardMarkup()
    master_button = types.InlineKeyboardButton(text='Ведущий', callback_data='ведущий')
    player_button = types.InlineKeyboardButton(text='Игрок', callback_data='игрок')
    keyboard.add(master_button, player_button)
    mafia_bot.send_message(user_id, 'Mafia_bot приветствует тебя! Если ты Ведущий, нажми кнопку "ведущий", если игрок - "игрок"', reply_markup=keyboard)


@mafia_bot.message_handler(content_types=['text'])
def help_message(message):
    mafia_bot.send_message(message.from_user.id, 'чтобы понять, как пользоваться ботом напиши `/start`')

# изменение 2
@mafia_bot.callback_query_handler(
    lambda call: call.data == 'ведущий' or call.data == 'игрок')
def choose_master_or_player(call):
    user_id = call.from_user.id
    match call.data:
        case 'ведущий':
            mafia_bot.send_message(user_id, f'Приветствую тебя ведущий!')
        case 'игрок':
            mafia_bot.send_message(user_id, f'Приветствую тебя игрок!')


mafia_bot.polling(none_stop=True, interval=0)
